#include <stdio.h>
int main(){
	printf("Hello, my student ID is 1906400311\n");
	return 0;
}
